# ASCEND Nerve

Android-first nervous-system regulation app built with Expo and React Native.

## Run locally

```bash
npm install
npx expo start
```

## Included in this starter

- Double-tap anchor session start
- 120-second default session
- +60-second extensions up to 300 seconds
- AppState-aware timer pause/resume
- Minimal session screen with breathing cue
- Typed card catalog using ASCEND anchor metadata
- Offline queue interface ready for Supabase adapters

## App identity

- Android package: `com.ascend.nerve`
- iOS bundle identifier: `com.ascend.nerve`
