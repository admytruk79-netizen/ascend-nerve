import { useEffect, useMemo, useRef, useState } from 'react';
import { AppState, type AppStateStatus, Pressable, SafeAreaView, StyleSheet, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { AnchorOrb } from './src/components/AnchorOrb';
import { cards } from './src/data/cards';
import {
  DEFAULT_SESSION_SECONDS,
  MAX_SESSION_SECONDS,
  extendSession,
  startAnchorSession,
} from './src/services/session';
import { enqueueWrite } from './src/services/offlineQueue';

export default function App() {
  const card = cards[0];
  const [active, setActive] = useState(false);
  const [remaining, setRemaining] = useState(DEFAULT_SESSION_SECONDS);
  const [planned, setPlanned] = useState(DEFAULT_SESSION_SECONDS);
  const appState = useRef<AppStateStatus>(AppState.currentState);
  const pausedAt = useRef<number | null>(null);

  useEffect(() => {
    if (!active) return;
    const timer = setInterval(() => {
      setRemaining((value) => {
        if (value <= 1) {
          clearInterval(timer);
          setActive(false);
          void enqueueWrite('session', {
            cardId: card?.id,
            completedAt: new Date().toISOString(),
            plannedSeconds: planned,
          });
          return 0;
        }
        return value - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [active, card?.id, planned]);

  useEffect(() => {
    const subscription = AppState.addEventListener('change', (next) => {
      if (appState.current === 'active' && next !== 'active') {
        pausedAt.current = Date.now();
      }
      if (appState.current !== 'active' && next === 'active' && pausedAt.current) {
        const elapsed = Math.floor((Date.now() - pausedAt.current) / 1000);
        setRemaining((value) => Math.max(0, value - elapsed));
        pausedAt.current = null;
      }
      appState.current = next;
    });
    return () => subscription.remove();
  }, []);

  const timeLabel = useMemo(() => {
    const minutes = Math.floor(remaining / 60).toString().padStart(2, '0');
    const seconds = (remaining % 60).toString().padStart(2, '0');
    return `${minutes}:${seconds}`;
  }, [remaining]);

  if (!card) return null;

  const begin = () => {
    const session = startAnchorSession(card);
    setPlanned(session.plannedSeconds);
    setRemaining(session.plannedSeconds);
    setActive(true);
    void enqueueWrite('session', session);
  };

  const addMinute = () => {
    const next = extendSession(planned);
    const delta = next - planned;
    setPlanned(next);
    setRemaining((value) => value + delta);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar style="light" />
      {!active ? (
        <View style={styles.home}>
          <Text style={styles.brand}>ASCEND</Text>
          <Text style={styles.kicker}>NERVOUS SYSTEM RESET</Text>
          <AnchorOrb title={card.title} subtitle="Double-tap to begin" onDoubleTap={begin} />
          <Text style={styles.note}>Breathe slowly. Stay with the image.</Text>
        </View>
      ) : (
        <View style={styles.session}>
          <Text style={styles.cue}>Breathe in · soften · breathe out</Text>
          <View style={styles.sessionOrb}><Text style={styles.sessionSymbol}>✦</Text></View>
          <Text style={styles.timer}>{timeLabel}</Text>
          <Text style={styles.sessionTitle}>{card.title}</Text>
          <Pressable
            disabled={planned >= MAX_SESSION_SECONDS}
            onPress={addMinute}
            style={({ pressed }) => [styles.extend, pressed && styles.pressed, planned >= MAX_SESSION_SECONDS && styles.disabled]}
          >
            <Text style={styles.extendText}>{planned >= MAX_SESSION_SECONDS ? 'Maximum 5 minutes' : '+ 60 seconds'}</Text>
          </Pressable>
          <Pressable onPress={() => setActive(false)} style={styles.finish}>
            <Text style={styles.finishText}>Finish session</Text>
          </Pressable>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#080B16' },
  home: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 28 },
  brand: { color: '#F3EFFF', fontSize: 34, letterSpacing: 7, fontWeight: '700' },
  kicker: { color: '#817A99', fontSize: 11, letterSpacing: 3, marginTop: 8, marginBottom: 54 },
  note: { color: '#77718D', marginTop: 54, fontSize: 13 },
  session: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 28 },
  cue: { color: '#C8C1DD', fontSize: 16, letterSpacing: 1, marginBottom: 42 },
  sessionOrb: { width: 250, height: 250, borderRadius: 125, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(104, 77, 177, 0.18)', borderWidth: 1, borderColor: 'rgba(209, 191, 255, 0.5)' },
  sessionSymbol: { color: '#F5F0FF', fontSize: 82 },
  timer: { color: '#FFFFFF', fontSize: 48, fontVariant: ['tabular-nums'], marginTop: 36, fontWeight: '300' },
  sessionTitle: { color: '#AFA8C7', marginTop: 12, fontSize: 16 },
  extend: { borderWidth: 1, borderColor: '#8171B4', borderRadius: 999, paddingVertical: 12, paddingHorizontal: 22, marginTop: 34 },
  extendText: { color: '#E9E2FF', fontSize: 14 },
  finish: { padding: 18, marginTop: 10 },
  finishText: { color: '#716B83', fontSize: 13 },
  pressed: { opacity: 0.72 },
  disabled: { opacity: 0.4 },
});
