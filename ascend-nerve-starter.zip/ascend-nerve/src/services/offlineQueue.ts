export type QueueItemType = 'session' | 'journal';

export interface QueueItem<T = unknown> {
  id: string;
  type: QueueItemType;
  payload: T;
  createdAt: string;
  attempts: number;
}

const memoryQueue: QueueItem[] = [];

export async function enqueueWrite<T>(type: QueueItemType, payload: T): Promise<void> {
  memoryQueue.push({
    id: `${type}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    type,
    payload,
    createdAt: new Date().toISOString(),
    attempts: 0,
  });
}

export async function getQueuedWrites(): Promise<readonly QueueItem[]> {
  return memoryQueue;
}

// Replace this in P2 with AsyncStorage or SQLite persistence and a Supabase sync adapter.
