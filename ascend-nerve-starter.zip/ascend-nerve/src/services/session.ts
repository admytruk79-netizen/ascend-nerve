import type { AnchorCard } from '../types/card';

export const DEFAULT_SESSION_SECONDS = 120;
export const SESSION_EXTENSION_SECONDS = 60;
export const MAX_SESSION_SECONDS = 300;

export interface AnchorSession {
  id: string;
  cardId: string;
  startedAt: string;
  plannedSeconds: number;
  completedAt?: string;
}

export function startAnchorSession(card: AnchorCard): AnchorSession {
  return {
    id: `session_${Date.now()}`,
    cardId: card.id,
    startedAt: new Date().toISOString(),
    plannedSeconds: DEFAULT_SESSION_SECONDS,
  };
}

export function extendSession(seconds: number): number {
  return Math.min(seconds + SESSION_EXTENSION_SECONDS, MAX_SESSION_SECONDS);
}
