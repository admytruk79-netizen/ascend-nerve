import type { AnchorCard } from '../types/card';

export const cards: AnchorCard[] = [
  {
    id: 'card_01',
    assetKey: 'anchor_the-flame-of-purity',
    title: 'The Flame of Purity',
    category: 'panic_crisis',
    acuteRecommended: true,
    version: 1,
  },
  {
    id: 'card_02',
    assetKey: 'anchor_cosmic-harmony',
    title: 'Cosmic Harmony',
    category: 'anger_friction',
    acuteRecommended: true,
    version: 1,
  },
  {
    id: 'card_03',
    assetKey: 'anchor_the-spiral-of-wisdom',
    title: 'The Spiral of Wisdom',
    category: 'racing_thoughts',
    acuteRecommended: true,
    version: 1,
  },
  {
    id: 'card_04',
    assetKey: 'anchor_celestial-awakening',
    title: 'Celestial Awakening',
    category: 'general_reflective',
    acuteRecommended: false,
    version: 1,
  },
  {
    id: 'card_05',
    assetKey: 'anchor_flame-of-glory',
    title: 'Flame of Glory',
    category: 'general_reflective',
    acuteRecommended: false,
    version: 1,
  },
  {
    id: 'card_06',
    assetKey: 'anchor_boundless-cycle',
    title: 'Boundless Cycle',
    category: 'general_reflective',
    acuteRecommended: false,
    version: 1,
  },
  {
    id: 'card_07',
    assetKey: 'anchor_the-dormant-spirit',
    title: 'The Dormant Spirit',
    category: 'general_reflective',
    acuteRecommended: false,
    version: 1,
  },
  {
    id: 'card_08',
    assetKey: 'anchor_the-radiant-source',
    title: 'The Radiant Source',
    category: 'panic_crisis',
    acuteRecommended: true,
    version: 1,
  }
];
