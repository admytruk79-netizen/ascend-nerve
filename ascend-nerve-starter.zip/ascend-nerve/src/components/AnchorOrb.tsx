import { Pressable, StyleSheet, Text, View } from 'react-native';

interface AnchorOrbProps {
  title: string;
  subtitle: string;
  onDoubleTap: () => void;
}

export function AnchorOrb({ title, subtitle, onDoubleTap }: AnchorOrbProps) {
  let lastTap = 0;

  const handlePress = () => {
    const now = Date.now();
    if (now - lastTap < 350) {
      onDoubleTap();
      lastTap = 0;
      return;
    }
    lastTap = now;
  };

  return (
    <Pressable accessibilityRole="button" accessibilityLabel={`Start ${title} session`} onPress={handlePress}>
      <View style={styles.orb}>
        <View style={styles.inner}>
          <Text style={styles.symbol}>✦</Text>
        </View>
      </View>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.subtitle}>{subtitle}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  orb: {
    width: 230,
    height: 230,
    borderRadius: 115,
    borderWidth: 1,
    borderColor: 'rgba(201, 175, 255, 0.55)',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(98, 72, 167, 0.16)',
    shadowColor: '#A88CFF',
    shadowOpacity: 0.45,
    shadowRadius: 28,
    elevation: 12,
  },
  inner: {
    width: 150,
    height: 150,
    borderRadius: 75,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(196, 171, 255, 0.16)',
  },
  symbol: { color: '#F3EFFF', fontSize: 70 },
  title: { color: '#F5F1FF', fontSize: 24, textAlign: 'center', marginTop: 28, fontWeight: '600' },
  subtitle: { color: '#AFA8C7', fontSize: 14, textAlign: 'center', marginTop: 8 },
});
