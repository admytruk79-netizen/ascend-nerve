export type CardCategory =
  | 'panic_crisis'
  | 'anger_friction'
  | 'racing_thoughts'
  | 'general_reflective';

export interface AnchorCard {
  id: string;
  assetKey: string;
  title: string;
  category: CardCategory;
  acuteRecommended: boolean;
  version: number;
}
